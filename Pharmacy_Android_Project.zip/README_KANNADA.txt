PHARMACY BILLING ANDROID PROJECT — ಕನ್ನಡ ಮಾರ್ಗದರ್ಶಿ

ಈ ZIP Android Studio project source code ಆಗಿದೆ. ಇದು ಈಗಾಗಲೇ compile ಮಾಡಿದ APK ಅಲ್ಲ. ಈ environmentನಲ್ಲಿ Android SDK/Gradle build setup ಲಭ್ಯವಿಲ್ಲದ ಕಾರಣ APK compile ಮಾಡಿಲ್ಲ.

ಮುಖ್ಯ ಆಯ್ಕೆ:
- Offline mode: ಪ್ರತಿ mobile/deviceನಲ್ಲಿ local data ಉಳಿಯುತ್ತದೆ.
- Branch ಆಯ್ಕೆ, medicine master, batch/expiry, purchase stock-in, GST sales, expired batch sale block, sales register, expiry report, CSV/JSON backup ಮತ್ತು draft Tally XML export.
- Branch data ಬೇರೆ deviceಗಳ ನಡುವೆ ಸ್ವಯಂಚಾಲಿತವಾಗಿ sync ಆಗುವುದಿಲ್ಲ. Multiple pharmaciesಗೆ production use ಮುನ್ನ secure sync server ಮತ್ತು conflict handling ಬೇಕು.
- GST rates medicine classification ಪ್ರಕಾರ verify ಮಾಡಬೇಕು. Tally XML draft ಮಾತ್ರ; live companyಗೆ ನೇರ import ಮಾಡಬೇಡಿ.
- Production releaseಗೆ ಮೊದಲು invoice PDF/print, CGST/SGST/IGST mapping, purchase/sales returns, login/roles, encrypted backup, audit logs, barcode camera, prescription/controlled-drug workflows ಮತ್ತು compliance testing ಸೇರಿಸಬೇಕು.

APK build:
1. Computerನಲ್ಲಿ Android Studio (stable) install ಮಾಡಿ.
2. ZIP extract ಮಾಡಿ Android Studioನಲ್ಲಿ ಈ folder ತೆರೆಯಿರಿ.
3. Gradle sync ಪೂರ್ಣಗೊಳಿಸಿ; ಅಗತ್ಯ Android SDK platformಗಳನ್ನು install ಮಾಡಿ.
4. Build > Build Bundle(s) / APK(s) > Build APK(s) ಆಯ್ಕೆ ಮಾಡಿ.
5. Debug APK app/build/outputs/apk/debug/app-debug.apk ನಲ್ಲಿ ಸಿಗುತ್ತದೆ.
6. ಮೊದಲು test data ಬಳಸಿ. ನಿಜವಾದ pharmacy invoicesಗೆ ಬಳಸುವ ಮೊದಲು GST/Tally mapping ಮತ್ತು data backup ಪರೀಕ್ಷಿಸಿ.

Offline data browser WebView local storageನಲ್ಲಿ ಉಳಿಯುತ್ತದೆ. App uninstall/data clear ಮಾಡಿದರೆ data ಕಳೆದುಹೋಗಬಹುದು. Backup ತೆಗೆದುಕೊಳ್ಳಿ.

ಅಂಗಡಿ ಹೆಸರು App ಒಳಗೇ ಸೃಷ್ಟಿಸುವುದು:
- Settings ತೆರೆಯಿರಿ.
- ಅಂಗಡಿಯ ಹೆಸರು, GSTIN, ವಿಳಾಸ ಮತ್ತು ಫೋನ್ ತುಂಬಿ "ಅಂಗಡಿ ವಿವರಗಳನ್ನು ಉಳಿಸಿ" ಒತ್ತಿ.
- ಬೇರೆ branch ಸೇರಿಸಲು "ಹೊಸ ಅಂಗಡಿ / Branch ಹೆಸರು" ತುಂಬಿ "+ ಹೊಸ ಅಂಗಡಿ ಸೇರಿಸಿ" ಒತ್ತಿ.
- ಇದು source project update; ಹೊಸ APK ಪಡೆಯಲು Android Studioನಲ್ಲಿ ಮತ್ತೆ Build APK(s) ಮಾಡಿ.

GitHub Cloud Build workflow:
- Project rootನಲ್ಲಿ .github/workflows/build-apk.yml ಸೇರಿಸಲಾಗಿದೆ.
- GitHub repositoryಗೆ source upload ಮಾಡಿದ ನಂತರ Actions tabನಲ್ಲಿ "Build Pharmacy Billing APK" workflow run ಮಾಡಿ.
- ಯಶಸ್ವಿಯಾದರೆ run pageನ Artifacts ವಿಭಾಗದಿಂದ Pharmacy-Billing-debug-APK ZIP download ಮಾಡಿ; ಒಳಗೆ app-debug.apk ಇರುತ್ತದೆ.
- This produces a DEBUG APK for testing only, not a signed production release.
